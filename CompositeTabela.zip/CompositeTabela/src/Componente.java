public interface Componente {
    public void imprimir();
}
