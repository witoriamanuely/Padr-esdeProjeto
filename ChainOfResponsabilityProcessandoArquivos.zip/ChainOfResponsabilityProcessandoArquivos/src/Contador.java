public interface Contador {
    int cont = 0;
    public static int contagem(String texto){
        return cont;
    }
}
