
public interface Alvo {

    public void adicionaMap();

}

