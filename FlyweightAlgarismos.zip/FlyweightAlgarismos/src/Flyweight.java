
public interface Flyweight {
    public int algarismo();
}
