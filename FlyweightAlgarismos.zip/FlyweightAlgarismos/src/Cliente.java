public class Cliente {
    public static void main(String args[]){
        FlyweightFactory imprime = new FlyweightFactory();
        imprime.imprimeAleatorio();
    }
}
